// okdownload — Netlify Function: download handler
// Supports YouTube (ytdl-core) + fallback for other platforms via RapidAPI

const https = require('https');

// ─── HELPER: simple HTTPS GET ───────────────────────────────────────────────
function httpsGet(url, headers = {}) {
  return new Promise((resolve, reject) => {
    const options = new URL(url);
    const req = https.request(
      { hostname: options.hostname, path: options.pathname + options.search, headers },
      (res) => {
        let data = '';
        res.on('data', chunk => data += chunk);
        res.on('end', () => {
          try { resolve(JSON.parse(data)); }
          catch { resolve(data); }
        });
      }
    );
    req.on('error', reject);
    req.end();
  });
}

// ─── DETECT PLATFORM ─────────────────────────────────────────────────────────
function detectPlatform(url) {
  if (/tiktok\.com/i.test(url))     return 'tiktok';
  if (/facebook\.com|fb\.watch/i.test(url)) return 'facebook';
  if (/instagram\.com/i.test(url))  return 'instagram';
  if (/youtu\.be|youtube\.com/i.test(url))  return 'youtube';
  if (/twitter\.com|x\.com/i.test(url))     return 'twitter';
  if (/vimeo\.com/i.test(url))      return 'vimeo';
  return 'generic';
}

// ─── YOUTUBE HANDLER ─────────────────────────────────────────────────────────
async function handleYouTube(url) {
  // ytdl-core must be installed: npm install ytdl-core
  // Uncomment when deployed with ytdl-core available:
  /*
  const ytdl = require('ytdl-core');
  if (!ytdl.validateURL(url)) throw new Error('Invalid YouTube URL');
  const info = await ytdl.getInfo(url);
  const format = ytdl.chooseFormat(info.formats, { quality: 'highestvideo' });
  return {
    link: format.url,
    filename: `${info.videoDetails.title}.mp4`,
    title: info.videoDetails.title,
    thumbnail: info.videoDetails.thumbnails?.[0]?.url,
    duration: info.videoDetails.lengthSeconds,
  };
  */

  // DEMO fallback (replace with real implementation above):
  return {
    link: url,
    filename: 'youtube-video.mp4',
    title: 'YouTube Video',
    note: 'ytdl-core not installed. Run: npm install ytdl-core'
  };
}

// ─── RAPIDAPI HANDLER (TikTok / Facebook / Instagram / Twitter) ──────────────
async function handleRapidAPI(url, platform) {
  const RAPIDAPI_KEY = process.env.RAPIDAPI_KEY; // set in Netlify env vars

  if (!RAPIDAPI_KEY) {
    return {
      link: url,
      filename: `${platform}-video.mp4`,
      note: 'Set RAPIDAPI_KEY in Netlify environment variables to enable real downloads.'
    };
  }

  // Using "Social Media Video Downloader" API on RapidAPI
  const apiUrl = `https://social-media-video-downloader.p.rapidapi.com/smvd/get/all?url=${encodeURIComponent(url)}`;

  const data = await httpsGet(apiUrl, {
    'X-RapidAPI-Key': RAPIDAPI_KEY,
    'X-RapidAPI-Host': 'social-media-video-downloader.p.rapidapi.com'
  });

  if (data && data.links && data.links.length > 0) {
    const best = data.links.find(l => l.quality === 'hd') || data.links[0];
    return {
      link: best.link,
      filename: `${platform}-video.mp4`,
      title: data.title || `${platform} video`,
      thumbnail: data.picture,
    };
  }

  throw new Error('Could not extract video from this URL. Make sure the video is public.');
}

// ─── MAIN HANDLER ────────────────────────────────────────────────────────────
exports.handler = async function(event) {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Content-Type': 'application/json'
  };

  // CORS preflight
  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  const url = event.queryStringParameters?.url;

  if (!url || !url.startsWith('http')) {
    return {
      statusCode: 400,
      headers,
      body: JSON.stringify({ error: 'Please provide a valid video URL.' })
    };
  }

  const platform = detectPlatform(url);

  try {
    let result;

    if (platform === 'youtube') {
      result = await handleYouTube(url);
    } else {
      result = await handleRapidAPI(url, platform);
    }

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({ ...result, platform })
    };

  } catch (err) {
    console.error('Download error:', err.message);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: err.message || 'Download failed. Please try another URL.' })
    };
  }
};

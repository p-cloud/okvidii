# okdownload — Netlify-Ready Money Site

## 🚀 Deploy to Netlify (2 minutes)

1. Drag & drop this folder to https://netlify.com/drop
2. Done — your site is live!

Or via Git:
```bash
git init
git add .
git commit -m "initial"
# Push to GitHub, then connect to Netlify
```

---

## 💰 Monetization Setup

### 1. Google AdSense
Uncomment the AdSense script in `public/index.html`:
```html
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-YOURPUBID" crossorigin="anonymous"></script>
```
Replace the `<!-- advertisement -->` placeholder divs with your ad units.

### 2. Real Downloader Backend

#### YouTube (ytdl-core)
```bash
npm install ytdl-core
```
Then uncomment the ytdl-core block in `netlify/functions/download.js`.

#### TikTok / Facebook / Instagram / Twitter
1. Sign up at https://rapidapi.com
2. Subscribe to "Social Media Video Downloader" API
3. Set your key in Netlify: **Site settings → Environment variables**
   - Key: `RAPIDAPI_KEY`
   - Value: your RapidAPI key

---

## 📁 Structure

```
okdownload/
├── public/
│   ├── index.html               ← Main homepage
│   ├── download-tiktok.html     ← SEO page (ranks on Google)
│   ├── download-facebook.html
│   ├── download-instagram.html
│   ├── download-youtube.html
│   ├── download-twitter.html
│   └── download-vimeo.html
├── netlify/
│   └── functions/
│       └── download.js          ← Backend downloader API
├── netlify.toml                 ← Netlify config
└── package.json
```

---

## 🔑 Environment Variables (Netlify Dashboard)

| Variable | Value | Required for |
|---|---|---|
| `RAPIDAPI_KEY` | your key | TikTok, FB, IG, Twitter |

---

## 📈 SEO Tips

Each platform page (`/download-tiktok.html` etc.) is pre-optimized with:
- Unique `<title>` and `<meta description>`
- Platform-specific keywords
- Step-by-step how-to content (Google loves this)

To add more pages, edit `seo-pages/make_seo.py` and run it again.

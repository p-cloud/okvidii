import os

pages = [
    {"slug":"download-tiktok","emoji":"🎵","platform":"TikTok","color":"#00e5a0","desc":"Download TikTok videos without watermark — free, fast, no app needed.","how":["Open TikTok and find the video you want to save.","Tap <strong>Share</strong> → <strong>Copy Link</strong>.","Paste the link in the box above and click <strong>Download</strong>.","Your video downloads instantly — no watermark, no signup."]},
    {"slug":"download-facebook","emoji":"📘","platform":"Facebook","color":"#4a90e2","desc":"Download Facebook videos in HD — public videos, reels, stories.","how":["Open Facebook and find the video.","Click the <strong>three dots (⋯)</strong> → <strong>Copy Link</strong>.","Paste the link above and click <strong>Download</strong>.","Choose HD or SD and save your video."]},
    {"slug":"download-instagram","emoji":"📸","platform":"Instagram","color":"#e1306c","desc":"Download Instagram Reels, videos and stories — no login required.","how":["Open the Instagram post or Reel you want.","Tap the <strong>⋯ menu</strong> → <strong>Copy Link</strong>.","Paste the link above and hit <strong>Download</strong>.","Save your video instantly to your device."]},
    {"slug":"download-youtube","emoji":"▶","platform":"YouTube","color":"#ff4040","desc":"Download YouTube videos in HD, 1080p, or audio-only MP3 format.","how":["Copy the YouTube video URL from your browser or app.","Paste it in the box above.","Click <strong>Download</strong> and choose your quality.","Save the video to watch offline."]},
    {"slug":"download-twitter","emoji":"🐦","platform":"Twitter / X","color":"#1da1f2","desc":"Download Twitter and X videos — GIFs, clips, and viral videos.","how":["Find the tweet with the video on Twitter/X.","Click <strong>Share</strong> → <strong>Copy link to Tweet</strong>.","Paste it above and press <strong>Download</strong>.","Save the video directly to your device."]},
    {"slug":"download-vimeo","emoji":"🎬","platform":"Vimeo","color":"#1ab7ea","desc":"Download Vimeo videos in high quality — free and simple.","how":["Open the Vimeo video you want.","Copy the URL from your browser address bar.","Paste it above and click <strong>Download</strong>.","Your video will be ready in seconds."]}
]

T = open("/home/claude/okdownload/seo-pages/template.html").read()

out = "/home/claude/okdownload/public"
for p in pages:
    sh = "\n    ".join([f'<div class="step"><div class="step-num">{i+1}</div><div class="step-text">{s}</div></div>' for i,s in enumerate(p["how"])])
    html = T.replace("{{PLATFORM}}",p["platform"]).replace("{{EMOJI}}",p["emoji"]).replace("{{COLOR}}",p["color"]).replace("{{DESC}}",p["desc"]).replace("{{STEPS}}",sh).replace("{{PLATFORM_LOWER}}",p["platform"].lower())
    with open(f"{out}/{p['slug']}.html","w") as f: f.write(html)
    print("✓", p["slug"])
